package com.example.munar_exam;

import  androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class SignupActivity extends AppCompatActivity {

    private EditText ssEmail;
    private EditText ssPassword;
    private EditText ssConfirmPassword;
    private Button ssRegister;

    private FirebaseAuth ssAuth;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        initComponents();

        ssRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                registerUser();
            }
        });

    }

    private void initComponents() {
       ssEmail = (EditText) findViewById(R.id.editEmail);
        ssPassword = (EditText) findViewById(R.id.editPassword);
        ssConfirmPassword = (EditText) findViewById(R.id.editConfirmPassword);

        ssRegister = (Button) findViewById(R.id.btnRegister);
        ssAuth = FirebaseAuth.getInstance();
    }

    private void registerUser() {
        String email = ssEmail.getText().toString().trim().toLowerCase();
        String password = ssPassword.getText().toString();
        String confirmPassword = ssConfirmPassword.getText().toString();

        if (!email.contains("@")) {
            ssEmail.setError("Invalid Email");
            return;
        }

        if (TextUtils.isEmpty(email)) {
            ssEmail.setError("Required field!");
            return;
        }

        if (TextUtils.isEmpty(password)) {
            ssPassword.setError("Required field!");
            return;
        }

        if (TextUtils.isEmpty(confirmPassword)) {
           ssConfirmPassword.setError("Required field!");
            return;
        }
        if (!password.equals(confirmPassword)) {
            ssConfirmPassword.setError("Same Password Needed");
            return;
        }

        ssAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (!task.isSuccessful()) {
                    Toast.makeText(getApplicationContext(), task.getException().getMessage(), Toast.LENGTH_LONG).show();
                }
                else {
                    Toast.makeText(getApplicationContext(), "Successful Registration", Toast.LENGTH_LONG).show();

                    FirebaseUser user = ssAuth.getCurrentUser();

                    user.sendEmailVerification().addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task task) {
                            if (!task.isSuccessful()) {
                                Toast.makeText(getApplicationContext(), task.getException().getMessage(), Toast.LENGTH_LONG).show();
                            }
                            else {
                                startActivity(new Intent(SignupActivity.this, com.example.munar_exam.LoginActivity.class));
                            }
                        }
                    });
                }

            }
        });
    }
}
