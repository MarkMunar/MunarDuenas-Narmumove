package com.example.munar_exam;

import android.app.NotificationManager;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;

public class MainActivity extends AppCompatActivity {

    private BottomNavigationView bottomNav;
    private FrameLayout frameLayout;
    private EditText editPickUp;
    private EditText editItem;
    private EditText editContact;
    private EditText editName;
    private Button buttonSave;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bottomNav = findViewById(R.id.main_bottom_navigation);
        frameLayout = findViewById(R.id.main_framelayout);




        if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction().replace(R.id.main_framelayout,
                    new HomeFragment()).commit();
        }


        bottomNav.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()){
                    case R.id.nav_home:
                        getSupportFragmentManager().beginTransaction().replace(R.id.main_framelayout,
                                new HomeFragment()).commit();
                }
                switch (item.getItemId()){
                    case R.id.nav_maps:
                        getSupportFragmentManager().beginTransaction().replace(R.id.main_framelayout,
                                new NavigationFragment()).commit();
                }
                switch (item.getItemId()){
                    case R.id.nav_setting:s:
                    getSupportFragmentManager().beginTransaction().replace(R.id.main_framelayout,
                            new SettingsFragment()).commit();
                }
                return true;

            }

        });
        Button btnLogin = (Button) findViewById(R.id.logout);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                openlogin();
            }
        });

    }

    public void openlogin() {
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
    }
} 











